
import React, { useState, FormEvent } from 'react';
import Hero from '../components/Hero';
import Reveal from '../components/Reveal';
import FaqItem from '../components/FaqItem';

const ContactPage: React.FC = () => {
  const [formState, setFormState] = useState({
    status: 'idle',
    message: ''
  });

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFormState({ status: 'loading', message: '' });

    const formData = new FormData(e.target as HTMLFormElement);
    const accessKey = formData.get('access_key');
    
    // NOTE: Replace this with your actual Web3Forms Access Key
    if (accessKey === 'YOUR_WEB3FORMS_ACCESS_KEY_HERE') {
        setFormState({ status: 'error', message: 'Please add your Web3Forms Access Key.' });
        return;
    }

    try {
      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        body: formData,
      });
      const data = await response.json();
      if (data.success) {
        setFormState({ status: 'success', message: 'Your message has been sent successfully!' });
      } else {
        setFormState({ status: 'error', message: data.message || 'An error occurred.' });
      }
    } catch (error) {
      setFormState({ status: 'error', message: 'An error occurred. Please try again.' });
    }
  };

  return (
    <>
      <Hero
        title="Get In Touch"
        subtitle="I'm here to answer any questions. Please get in touch to book your consultation."
      />

      <section className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
            <div className="lg:w-3/5">
              <Reveal>
                <h2 className="text-4xl md:text-5xl font-semibold mb-6">Send An Enquiry</h2>
                <p className="text-lg mb-8">Please fill out the form below to get started. A consultation is required for all new clients. I'll get back to you as soon as possible!</p>
                {formState.status === 'success' ? (
                    <div className="bg-green-100 border border-green-300 text-green-800 p-6 rounded-2xl">
                        <h3 className="text-2xl font-semibold mb-2">Thank You!</h3>
                        <p>{formState.message}</p>
                    </div>
                ) : (
                <form onSubmit={handleSubmit}>
                  <input type="hidden" name="access_key" value="YOUR_WEB3FORMS_ACCESS_KEY_HERE" />
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <input type="text" name="name" placeholder="Your Name" className="w-full p-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--color-accent)] transition-all" required />
                    <input type="email" name="email" placeholder="Your Email" className="w-full p-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--color-accent)] transition-all" required />
                  </div>
                  <div className="mb-6">
                    <input type="tel" name="phone" placeholder="Your Phone Number (optional)" className="w-full p-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--color-accent)] transition-all" />
                  </div>
                  <div className="mb-6">
                    <textarea name="message" placeholder="Your Message (e.g., desired treatment, availability)" rows={5} className="w-full p-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--color-accent)] transition-all" required></textarea>
                  </div>
                  <div className="text-left">
                    <button type="submit" className="btn-primary" disabled={formState.status === 'loading'}>
                      {formState.status === 'loading' ? 'Sending...' : 'Send Enquiry'}
                    </button>
                  </div>
                  {formState.status === 'error' && <div className="mt-4 text-sm text-red-600">{formState.message}</div>}
                </form>
                )}
              </Reveal>
            </div>
            <div className="lg:w-2/5">
              <Reveal delay={200}>
                <ContactDetailsCard />
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="container mx-auto px-6">
          <Reveal>
            <h3 className="text-4xl md:text-5xl font-semibold mb-8 text-center">We Serve All of Kent</h3>
            <p className="text-lg text-center max-w-2xl mx-auto mb-8">Based in Kent, we provide our luxury mobile services to your doorstep, wherever you are in the county.</p>
            <div className="max-w-4xl mx-auto rounded-2xl shadow-xl overflow-hidden border border-gray-100">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d160241.6703554091!2d0.4852003885669536!3d51.2751713437295!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47ded56298e9c5c1%3A0x66f7f6f70751919!2sKent%2C%20UK!5e0!3m2!1sen!2sus" width="100%" height="450" style={{ border: 0 }} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade" title="Google Map of Kent, UK"></iframe>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="py-24 bg-white">
        <div className="container mx-auto px-6 max-w-4xl">
          <div className="text-center mb-16">
            <Reveal><h2 className="text-4xl md:text-5xl font-semibold">Frequently Asked Questions</h2></Reveal>
          </div>
          <Reveal delay={200}>
            <FaqItem question="What does 'mobile aesthetics' mean?">
              <p>It means I bring the clinic to you! I perform all treatments in the comfort, privacy, and convenience of your own home. I bring a portable treatment bed, medical-grade supplies, and everything needed for a safe, hygienic, and professional service.</p>
            </FaqItem>
            <FaqItem question="Is a consultation required for new clients?">
              <p>Yes, all new clients require a full consultation. This is crucial for me to assess your medical history, understand your aesthetic goals, discuss treatment options, and ensure you are a suitable candidate. For anti-wrinkle injections, a consultation with my nurse prescriber is also legally required.</p>
            </FaqItem>
            <FaqItem question="What areas in Kent do you cover?">
              <p>I cover most of Kent and surrounding areas. A small travel fee may apply depending on your distance from my base. Please get in touch with your postcode, and I can confirm any travel costs before your booking.</p>
            </FaqItem>
          </Reveal>
        </div>
      </section>
    </>
  );
};

const ContactDetailsCard: React.FC = () => (
    <div className="bg-gray-50 p-8 md:p-12 rounded-2xl shadow-lg border border-gray-100">
        <h3 className="text-3xl font-semibold mb-8">Contact Details</h3>
        <div className="space-y-6">
            <ContactDetailItem icon="fas fa-map-marker-alt" title="Service Area" content={<p>Proudly serving Kent & surrounding areas. We come to you!</p>} />
            <ContactDetailItem icon="fas fa-envelope" title="Email" content={<a href="mailto:info@aestheticsbyabs.co.uk" className="hover:text-[var(--color-accent)] transition-colors">info@aestheticsbyabs.co.uk</a>} />
            <ContactDetailItem icon="fas fa-phone" title="Phone" content={<a href="tel:07849432449" className="hover:text-[var(--color-accent)] transition-colors">07849 432449</a>} />
            <ContactDetailItem icon="fab fa-whatsapp" title="WhatsApp" content={<a href="https://wa.me/447849432449" target="_blank" rel="noopener noreferrer" className="hover:text-[var(--color-accent)] transition-colors">Click to Chat</a>} />
            <ContactDetailItem icon="fab fa-instagram" title="Instagram" content={<a href="https://www.instagram.com/aestheticsbyabs" target="_blank" rel="noopener noreferrer" className="hover:text-[var(--color-accent)] transition-colors">@aestheticsbyabs</a>} />
        </div>
    </div>
);

const ContactDetailItem: React.FC<{icon: string, title: string, content: React.ReactNode}> = ({icon, title, content}) => (
    <div className="flex items-start gap-4">
        <i className={`${icon} text-2xl text-[var(--color-accent)] mt-1`}></i>
        <div>
            <h4 className="text-xl font-semibold">{title}</h4>
            {content}
        </div>
    </div>
);

export default ContactPage;
