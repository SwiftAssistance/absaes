import React from 'react';
import { Link } from 'react-router-dom';
import Hero from '../components/Hero';
import Reveal from '../components/Reveal';

const HomePage: React.FC = () => {
  return (
    <>
      <Hero
        size="large"
        title={<>Enhance Your <br />Natural Beauty</>}
        subtitle="Luxury mobile aesthetic treatments, delivered to your doorstep in Kent. Experience premium, personalised care in the comfort of your own home."
      >
        <Link to="/contact" className="btn-primary">
          Book Your Consultation
        </Link>
      </Hero>

      {/* Services Section */}
      <section id="services" className="py-24">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <Reveal>
              <h2 className="text-4xl md:text-5xl font-semibold">Our Signature Treatments</h2>
            </Reveal>
            <Reveal delay={200}>
              <p className="text-lg mt-4 max-w-2xl mx-auto">
                Bespoke treatments designed to rejuvenate, refresh, and refine.
              </p>
            </Reveal>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            <Reveal><ServiceCard icon="fa-fire" title="Fat Dissolving Injections" description="Target stubborn areas of fat and sculpt your body with our safe and effective dissolving treatments." /></Reveal>
            <Reveal delay={200}><ServiceCard icon="fa-prescription-bottle" title="Vitamin Injections" description="Boost your well-being from the inside out. Enhance energy, mood, and overall health." /></Reveal>
            <Reveal delay={400}><ServiceCard icon="fa-magic-wand-sparkles" title="Anti-Wrinkle Injections" description="Soften fine lines and prevent future wrinkles for a flawlessly smooth and youthful complexion." /></Reveal>
            <Reveal><ServiceCard icon="fa-lips" title="Dermal Lip Fillers" description="Restore volume, define contours, and hydrate your lips for a naturally plump and beautiful result." /></Reveal>
            <Reveal delay={200}><ServiceCard icon="fa-syringe" title="Lip Enhancement" description="Our signature lip enhancement focuses on creating balanced, defined, and beautifully shaped lips." /></Reveal>
            <Reveal delay={400}><ServiceCard icon="fa-star" title="Skin Boosters" description="Achieve a radiant, 'glass skin' glow with our intensive skin-boosting treatments." /></Reveal>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <Reveal>
                <img src="https://picsum.photos/600/600?image=1060" alt="Aesthetics by Abs practitioner" className="rounded-2xl shadow-xl w-full h-auto object-cover" style={{ aspectRatio: '1/1' }} />
              </Reveal>
            </div>
            <div className="md:w-1/2">
              <Reveal>
                <h2 className="text-4xl md:text-5xl font-semibold mb-6">Luxury & Convenience, <br />Beautifully Combined.</h2>
                <p className="text-lg mb-4">
                  Welcome to Aesthetics by Abs, your private mobile beauty clinic serving Kent. We believe that self-care should be both luxurious and effortless.
                </p>
                <p className="mb-6">
                  Founded by Abs, a fully qualified and insured aesthetics practitioner, our mission is to provide the highest standard of non-surgical treatments in the privacy and comfort of your own home.
                </p>
                <Link to="/services" className="btn-secondary">Explore Treatments</Link>
              </Reveal>
            </div>
          </div>
        </div>
      </section>
      
      {/* Why Choose Us Section */}
      <section id="why-choose-us" className="py-24">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <Reveal><h2 className="text-4xl md:text-5xl font-semibold">The Aesthetics by Abs Difference</h2></Reveal>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            <Reveal><WhyChooseCard icon="fa-home" title="Mobile Convenience" description="Receive expert treatments in the comfort and privacy of your home." /></Reveal>
            <Reveal delay={200}><WhyChooseCard icon="fa-user-shield" title="Qualified Professional" description="Fully insured and certified practitioner dedicated to your safety and results." /></Reveal>
            <Reveal delay={400}><WhyChooseCard icon="fa-gem" title="Premium Products" description="We use only industry-leading, CE-marked products for superior, lasting results." /></Reveal>
            <Reveal delay={600}><WhyChooseCard icon="fa-hand-sparkles" title="Personalised Care" description="Bespoke consultations and treatment plans tailored to your unique goals." /></Reveal>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-24" style={{ backgroundImage: 'linear-gradient(to top, var(--color-primary), var(--color-bg))' }}>
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <Reveal><h2 className="text-4xl md:text-5xl font-semibold">What Our Clients Say</h2></Reveal>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Reveal><TestimonialCard quote="Abs is amazing! She made me feel so at ease in my own home. My lips have never looked better. So natural and just what I asked for!" author="- Sophie L, Maidstone" /></Reveal>
            <Reveal delay={200}><TestimonialCard quote="The convenience is a game-changer. Professional, hygienic, and so talented. I had the anti-wrinkle injections and I'm thrilled." author="- Emily R, Canterbury" /></Reveal>
            <Reveal delay={400}><TestimonialCard quote="I was nervous about fat-dissolving, but Abs explained everything. The results are incredible. 100% recommend her." author="- Jessica T, Sevenoaks" /></Reveal>
          </div>
        </div>
      </section>
    </>
  );
};

// Sub-components for HomePage
const ServiceCard: React.FC<{ icon: string; title: string; description: string }> = ({ icon, title, description }) => (
  <div className="service-card text-center hover-box-effect h-full">
    <i className={`fas ${icon} text-4xl mb-4 text-[var(--color-accent)]`}></i>
    <h3 className="text-2xl font-semibold mb-3">{title}</h3>
    <p>{description}</p>
  </div>
);

const WhyChooseCard: React.FC<{ icon: string; title: string; description: string }> = ({ icon, title, description }) => (
    <div className="hover-box-effect h-full">
        <i className={`fas ${icon} text-4xl mb-4 text-[var(--color-accent)]`}></i>
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p>{description}</p>
    </div>
);

const TestimonialCard: React.FC<{ quote: string; author: string }> = ({ quote, author }) => (
    <div className="text-center p-8 h-full">
        <div className="text-lg mb-4 text-[var(--color-accent)]">
            <i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i>
        </div>
        <p className="text-xl italic mb-6">"{quote}"</p>
        <h4 className="text-lg font-semibold">{author}</h4>
    </div>
);

export default HomePage;