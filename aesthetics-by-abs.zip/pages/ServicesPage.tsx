
import React, { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import Hero from '../components/Hero';
import Reveal from '../components/Reveal';
import FaqItem from '../components/FaqItem';

const services = [
  { id: 'dermal-fillers', title: 'Dermal Lip Fillers', icon: 'fa-droplet' },
  { id: 'lip-enhancement', title: 'Lip Enhancement', icon: 'fa-syringe' },
  { id: 'anti-wrinkle', title: 'Anti-Wrinkle', icon: 'fa-magic-wand-sparkles' },
  { id: 'fat-dissolving', title: 'Fat Dissolving', icon: 'fa-fire' },
  { id: 'vitamin-injections', title: 'Vitamin Injections', icon: 'fa-prescription-bottle' },
  { id: 'skin-boosters', title: 'Skin Boosters', icon: 'fa-star' },
];

const ServicesPage: React.FC = () => {
  const [activeService, setActiveService] = useState('dermal-fillers');
  const contentContainerRef = useRef<HTMLDivElement>(null);

  const handleNavClick = (id: string) => {
    setActiveService(id);
    if (window.innerWidth < 1024 && contentContainerRef.current) {
        contentContainerRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <>
      <Hero
        title="Our Treatment Menu"
        subtitle="Discover our curated selection of premium aesthetic treatments, all designed to enhance your natural beauty."
      />
      
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
            <aside className="lg:w-1/3">
              <Reveal>
                <div className="sticky top-32 bg-[var(--color-bg)] p-4 rounded-2xl shadow-sm border border-gray-100">
                  <h2 className="text-3xl font-semibold mb-6 px-2">Our Services</h2>
                  <nav className="flex flex-col space-y-2">
                    {services.map(service => (
                      <button 
                        key={service.id}
                        className={`service-nav-link ${activeService === service.id ? 'active' : ''}`}
                        onClick={() => handleNavClick(service.id)}
                      >
                        <i className={`fas ${service.icon} w-6 mr-3 text-lg`}></i>
                        <span className="whitespace-nowrap">{service.title}</span>
                      </button>
                    ))}
                  </nav>
                </div>
              </Reveal>
            </aside>

            <main className="lg:w-2/3">
              <Reveal delay={200}>
                <div ref={contentContainerRef} className="bg-white p-8 md:p-12 rounded-2xl shadow-lg border border-gray-100 min-h-[500px]">
                  <ServiceContent activeService={activeService} />
                </div>
              </Reveal>
            </main>
          </div>
        </div>
      </section>

      <section id="faq" className="py-24 bg-white">
        <div className="container mx-auto px-6 max-w-4xl">
          <div className="text-center mb-16">
            <Reveal><h2 className="text-4xl md:text-5xl font-semibold">Frequently Asked Questions</h2></Reveal>
            <Reveal delay={200}><p className="text-lg mt-4 max-w-2xl mx-auto">Your questions, answered. Here’s what you need to know about our mobile services.</p></Reveal>
          </div>
          <Reveal delay={400}>
            <FaqItem question="What does 'mobile aesthetics' mean?">
              <p>It means I bring the clinic to you! I perform all treatments in the comfort, privacy, and convenience of your own home. I bring a portable treatment bed, medical-grade supplies, and everything needed for a safe, hygienic, and professional service.</p>
            </FaqItem>
            <FaqItem question="Is a consultation required for new clients?">
              <p>Yes, all new clients require a full consultation. This is crucial for me to assess your medical history, understand your aesthetic goals, discuss treatment options, and ensure you are a suitable candidate. For anti-wrinkle injections, a consultation with my nurse prescriber is also legally required.</p>
            </FaqItem>
            <FaqItem question="What products do you use?">
              <p>I am committed to safety and quality. I only use premium, industry-leading, CE-marked products for all my treatments. This ensures you receive the best possible, longest-lasting results in the safest manner.</p>
            </FaqItem>
          </Reveal>
        </div>
      </section>
    </>
  );
};

const ServiceDetailList: React.FC<{ items: string[] }> = ({ items }) => (
    <ul className="service-detail-list list-none p-0 mb-8">
        {items.map((item, index) => (
            <li key={index} className="relative pl-8 mb-3 text-lg before:content-['\f005'] before:font-['Font_Awesome_6_Free'] before:font-black before:text-[var(--color-accent)] before:absolute before:left-0 before:top-[5px] before:text-base">
                {item}
            </li>
        ))}
    </ul>
);

const ServiceContent: React.FC<{ activeService: string }> = ({ activeService }) => {
    const content = {
        'dermal-fillers': {
            title: 'Dermal Lip Fillers',
            description: "Our dermal lip filler treatments are designed to restore volume, define contours, and provide deep hydration for naturally plump and beautiful results. We focus on enhancing your unique shape.",
            details: ["Adds natural-looking volume and plumpness.", "Defines the cupid's bow and border.", "Hydrates and smooths fine lines on the lips.", "Corrects asymmetry for a balanced smile."]
        },
        'lip-enhancement': {
            title: 'Signature Lip Enhancement',
            description: "Our signature lip enhancement is a bespoke treatment focused on creating beautifully shaped, defined, and balanced lips. This is perfect for those seeking a subtle enhancement or a more noticeable, yet natural, pout.",
            details: ["Bespoke shaping tailored to your facial structure.", "Focuses on definition and enhancement.", "Uses premium, long-lasting fillers.", "Ideal for first-timers and enhancements."]
        },
        'anti-wrinkle': {
            title: 'Anti-Wrinkle Injections',
            description: "Soften fine lines and prevent new ones from forming. Our anti-wrinkle treatments relax targeted facial muscles, resulting in a flawlessly smooth, refreshed, and more youthful complexion.",
            details: ["Targets frown lines, forehead lines, and crow's feet.", "Prevents the deepening of dynamic wrinkles.", "Creates a natural, 'well-rested' look.", "Quick, safe, and highly effective procedure."]
        },
        'fat-dissolving': {
            title: 'Fat Dissolving Injections',
            description: "Permanently eliminate stubborn pockets of fat that are resistant to diet and exercise. This treatment is ideal for sculpting areas like the chin, abdomen, and thighs for a more defined contour.",
            details: ["Targets and destroys fat cells permanently.", "Ideal for double chins, jowls, and body areas.", "Non-surgical alternative to liposuction.", "Minimal downtime and gradual, natural results."]
        },
        'vitamin-injections': {
            title: 'Vitamin Injections',
            description: "Boost your well-being from the inside out. Our vitamin injections (like B12) bypass the digestive system for 100% absorption, helping to enhance energy levels, improve mood, and support overall health.",
            details: ["Increases energy levels and fights fatigue.", "Boosts metabolism and aids in weight loss.", "Improves sleep quality and concentration.", "Supports a healthy immune system."]
        },
        'skin-boosters': {
            title: 'Skin Boosters',
            description: "Achieve a radiant, 'glass skin' glow with our intensive skin-boosting treatments. These micro-injections deliver deep hydration and stimulate collagen, improving skin texture, elasticity, and luminosity.",
            details: ["Delivers intense, deep-skin hydration.", "Stimulates natural collagen and elastin production.", "Reduces fine lines and improves skin texture.", "Creates a luminous, dewy, and radiant glow."]
        }
    };

    return (
        <>
            {Object.entries(content).map(([key, value]) => (
                <div key={key} className={`service-content-block ${activeService === key ? 'service-content-block-active' : 'hidden'}`}>
                    <h2 className="text-4xl font-semibold mb-6">{value.title}</h2>
                    <p className="text-lg mb-6">{value.description}</p>
                    <ServiceDetailList items={value.details} />
                    <Link to="/contact" className="btn-primary">Book Your Consultation</Link>
                </div>
            ))}
        </>
    );
};

export default ServicesPage;
