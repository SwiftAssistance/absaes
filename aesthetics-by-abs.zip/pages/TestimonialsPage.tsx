
import React from 'react';
import Hero from '../components/Hero';
import Reveal from '../components/Reveal';
import { Link } from 'react-router-dom';

const testimonials = [
    {
        name: "Sophie L, Maidstone",
        title: "So natural and just what I asked for!",
        quote: "Abs is amazing! She made me feel so at ease in my own home. My lips have never looked better. So natural and just what I asked for!",
        img: "https://picsum.photos/600/600?image=1027"
    },
    {
        name: "Emily R, Canterbury",
        title: "The convenience is a game-changer.",
        quote: "Professional, hygienic, and so talented. I had the anti-wrinkle injections and I'm thrilled. The convenience is a game-changer.",
        img: "https://picsum.photos/600/600?image=1025"
    },
    {
        name: "Jessica T, Sevenoaks",
        title: "The results are incredible.",
        quote: "I was nervous about fat-dissolving, but Abs explained everything. The results are incredible. 100% recommend her.",
        img: "https://picsum.photos/600/600?image=1011"
    },
    {
        name: "Megan H, Ashford",
        title: "My skin is literally glowing!",
        quote: "My skin is literally glowing after the skin booster treatment. Abs is so knowledgeable and gentle. Can't wait for my next session!",
        img: "https://picsum.photos/600/600?image=996"
    },
    {
        name: "David B, Tunbridge Wells",
        title: "I feel so much more energetic.",
        quote: "I feel so much more energetic since starting the B12 injections. Abs is so professional and makes the whole process quick and painless.",
        img: "https://picsum.photos/600/600?image=836"
    }
];

const TestimonialsPage: React.FC = () => {
    return (
        <>
            <Hero
                title="What Our Clients Say"
                subtitle="Real stories from real clients. See the difference for yourself."
            />
            
            <section className="py-24 bg-white">
                <div className="container mx-auto px-6">
                    <div className="max-w-4xl mx-auto flex flex-col gap-16 md:gap-24">
                        {testimonials.map((testimonial, index) => (
                            <TestimonialItem key={index} {...testimonial} reversed={index % 2 !== 0} />
                        ))}
                    </div>
                </div>
            </section>
            
            <section className="py-24">
                <div className="container mx-auto px-6">
                    <Reveal>
                        <div className="max-w-4xl mx-auto text-center">
                            <h2 className="text-4xl md:text-5xl font-semibold mb-4">Ready to Begin?</h2>
                            <p className="text-lg mb-10 max-w-2xl mx-auto">Get in touch today to book your private consultation and start your journey.</p>
                            <Link to="/contact" className="btn-primary">Book Now</Link>
                        </div>
                    </Reveal>
                </div>
            </section>
        </>
    );
};

interface TestimonialItemProps {
    name: string;
    title: string;
    quote: string;
    img: string;
    reversed?: boolean;
}

const TestimonialItem: React.FC<TestimonialItemProps> = ({ name, title, quote, img, reversed }) => {
    const direction = reversed ? 'md:flex-row-reverse' : 'md:flex-row';

    return (
        <Reveal>
            <div className={`md:flex ${direction} md:items-center md:gap-12`}>
                <div className="md:w-2/5 mb-8 md:mb-0">
                    <img src={img} alt={`Happy client ${name}`} className="rounded-2xl shadow-xl w-full h-auto object-cover" style={{ aspectRatio: '1/1' }} />
                </div>
                <div className="md:w-3/5">
                    <div className="text-lg mb-4" style={{ color: 'var(--color-accent)' }}>
                        <i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i>
                    </div>
                    <h3 className="text-3xl md:text-4xl font-semibold mb-4">"{title}"</h3>
                    <p className="text-xl italic mb-6" style={{ fontFamily: 'var(--font-heading)', color: 'var(--color-text)' }}>
                        "{quote}"
                    </p>
                    <h4 className="text-lg font-semibold">- {name}</h4>
                </div>
            </div>
        </Reveal>
    );
};

export default TestimonialsPage;
