
import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#2C2C2C] text-gray-300 pt-24 pb-8">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center md:text-left">
          <div>
            <h3 className="text-3xl font-semibold text-white mb-2" style={{ fontFamily: 'var(--font-heading)' }}>Aesthetics by Abs</h3>
            <p>Luxury Mobile Aesthetics in Kent</p>
            <p className="mt-4 text-sm text-gray-400">
              Fully qualified and insured practitioner providing luxury treatments in the comfort of your home.
            </p>
            <div className="flex space-x-5 mt-6 justify-center md:justify-start">
              <a href="https://www.instagram.com/aestheticsbyabs" target="_blank" rel="noopener noreferrer" className="text-2xl hover:text-[var(--color-primary)] transition-colors" aria-label="Instagram"><i className="fab fa-instagram"></i></a>
              <a href="https://www.facebook.com/aestheticsbyabs" target="_blank" rel="noopener noreferrer" className="text-2xl hover:text-[var(--color-primary)] transition-colors" aria-label="Facebook"><i className="fab fa-facebook-f"></i></a>
              <a href="https://www.tiktok.com/@aestheticsbyabs" target="_blank" rel="noopener noreferrer" className="text-2xl hover:text-[var(--color-primary)] transition-colors" aria-label="TikTok"><i className="fab fa-tiktok"></i></a>
            </div>
          </div>

          <div>
            <h4 className="text-xl font-semibold text-white mb-4 uppercase tracking-wider">Quick Links</h4>
            <nav className="space-y-3">
              <Link to="/" className="block footer-link">Home</Link>
              <Link to="/services" className="block footer-link">Services</Link>
              <Link to="/about" className="block footer-link">About Me</Link>
              <Link to="/testimonials" className="block footer-link">Testimonials</Link>
              <Link to="/contact" className="block footer-link">Contact</Link>
            </nav>
          </div>

          <div>
            <h4 className="text-xl font-semibold text-white mb-4 uppercase tracking-wider">Our Services</h4>
            <nav className="space-y-3">
              <Link to="/services" className="block footer-link">Fat Dissolving</Link>
              <Link to="/services" className="block footer-link">Vitamin Injections</Link>
              <Link to="/services" className="block footer-link">Anti-Wrinkle</Link>
              <Link to="/services" className="block footer-link">Dermal Lip Fillers</Link>
              <Link to="/services" className="block footer-link">Skin Boosters</Link>
            </nav>
          </div>

          <div>
            <h4 className="text-xl font-semibold text-white mb-4 uppercase tracking-wider">Get In Touch</h4>
            <div className="space-y-4">
              <div className="flex items-center justify-center md:justify-start gap-3">
                <i className="fas fa-phone text-lg text-[var(--color-accent)]"></i>
                <a href="tel:07849432449" className="footer-link">07849 432449</a>
              </div>
              <div className="flex items-center justify-center md:justify-start gap-3">
                <i className="fas fa-envelope text-lg text-[var(--color-accent)]"></i>
                <a href="mailto:info@aestheticsbyabs.co.uk" className="footer-link">info@aestheticsbyabs.co.uk</a>
              </div>
              <div className="flex items-start justify-center md:justify-start gap-3">
                <i className="fas fa-map-marker-alt text-lg text-[var(--color-accent)] mt-1"></i>
                <div>
                  <p>Serving Kent & Surrounding Areas</p>
                  <p className="text-sm text-gray-400">We bring the clinic to you.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-16 pt-8 text-center text-gray-400 text-sm">
          <p>&copy; {currentYear} Aesthetics by Abs. All rights reserved.</p>
          <p className="mt-1">
            <Link to="#" className="footer-link">Privacy Policy</Link> | 
            <Link to="#" className="footer-link">Cookie Policy</Link>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
