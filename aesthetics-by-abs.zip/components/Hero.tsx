import React from 'react';
import Reveal from './Reveal';

interface HeroProps {
  title: React.ReactNode;
  subtitle: string;
  children?: React.ReactNode;
  size?: 'large' | 'small';
}

const AnimatedHearts: React.FC = () => (
    <div className="hero-animation-container">
        <i className="fas fa-heart hero-heart heart-1"></i>
        <i className="fas fa-heart hero-heart heart-2"></i>
        <i className="fas fa-heart hero-heart heart-3"></i>
        <i className="fas fa-heart hero-heart heart-4"></i>
        <i className="fas fa-heart hero-heart heart-5"></i>
        <i className="fas fa-heart hero-heart heart-6"></i>
        <i className="fas fa-heart hero-heart heart-7"></i>
        <i className="fas fa-heart hero-heart heart-8"></i>
        <i className="fas fa-heart hero-heart heart-9"></i>
        <i className="fas fa-heart hero-heart heart-10"></i>
    </div>
);


const Hero: React.FC<HeroProps> = ({ title, subtitle, children, size = 'small' }) => {
    const heroClasses = size === 'large'
    ? "relative min-h-screen flex items-center justify-center pt-32 pb-24 md:pt-0 hero-gradient"
    : "relative pt-40 pb-24 hero-gradient";

  return (
    <section className={heroClasses}>
      <AnimatedHearts />
      <div className="container mx-auto px-6 text-center relative z-10">
        <div className="max-w-3xl mx-auto">
            <Reveal>
                <h1 className="text-5xl md:text-7xl font-bold" style={{ lineHeight: 1.2 }}>
                    {title}
                </h1>
            </Reveal>
            <Reveal delay={200}>
                <p className="mt-6 mb-10 text-lg md:text-xl max-w-lg mx-auto">
                    {subtitle}
                </p>
            </Reveal>
            {children && <Reveal delay={400}>{children}</Reveal>}
        </div>
      </div>
    </section>
  );
};

export default Hero;