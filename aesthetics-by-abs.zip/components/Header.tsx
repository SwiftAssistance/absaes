
import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const closeMenu = () => setIsMenuOpen(false);

  const navLinkClasses = ({ isActive }: { isActive: boolean }) =>
    `nav-link ${isActive ? 'active' : ''}`;
  
  const mobileNavLinkClasses = "nav-link-mobile";

  const navLinks = [
    { to: '/', text: 'Home' },
    { to: '/services', text: 'Services' },
    { to: '/about', text: 'About' },
    { to: '/testimonials', text: 'Testimonials' },
    { to: '/contact', text: 'Contact' },
  ];

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 glass-effect ${isScrolled ? 'shadow-lg' : 'shadow-md'}`}>
      <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
        <Link to="/" className="text-3xl font-bold" style={{ fontFamily: 'var(--font-heading)', color: 'var(--color-heading)' }} onClick={closeMenu}>
          Aesthetics by Abs
        </Link>
        
        <div className="hidden md:flex space-x-8">
          {navLinks.map(link => (
            <NavLink key={link.to} to={link.to} className={navLinkClasses}>
              {link.text}
            </NavLink>
          ))}
        </div>
        
        <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden text-2xl text-[var(--color-heading)]">
          <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'}`}></i>
        </button>
      </nav>
      
      {isMenuOpen && (
        <div className="md:hidden bg-white/95 backdrop-blur-lg w-full absolute left-0 top-full shadow-lg">
          {navLinks.map(link => (
            <NavLink key={link.to} to={link.to} className={mobileNavLinkClasses} onClick={closeMenu}>
              {link.text}
            </NavLink>
          ))}
        </div>
      )}
    </header>
  );
};

export default Header;
