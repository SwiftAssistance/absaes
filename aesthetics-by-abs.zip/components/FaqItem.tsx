
import React, { useState, useRef, useEffect } from 'react';

interface FaqItemProps {
  question: string;
  children: React.ReactNode;
}

const FaqItem: React.FC<FaqItemProps> = ({ question, children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  return (
    <div className="faq-item border-b border-gray-200">
      <button
        className="faq-question flex justify-between items-center w-full py-6 px-2 cursor-pointer bg-transparent border-none text-left"
        onClick={() => setIsOpen(!isOpen)}
      >
        <h3 className="text-xl font-semibold text-[var(--color-heading)]">{question}</h3>
        <i className={`fas fa-plus faq-icon text-md text-[var(--color-accent)] transition-transform duration-300 ease ${isOpen ? 'transform rotate-45' : ''}`}></i>
      </button>
      <div
        ref={contentRef}
        style={{ maxHeight: isOpen ? `${contentRef.current?.scrollHeight}px` : '0' }}
        className="faq-answer overflow-hidden transition-all duration-500 ease-in-out px-2"
      >
        <div className="pb-6 text-base leading-relaxed">
            {children}
        </div>
      </div>
    </div>
  );
};

export default FaqItem;
