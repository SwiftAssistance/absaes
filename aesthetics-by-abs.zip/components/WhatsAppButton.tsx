
import React from 'react';

const WhatsAppButton: React.FC = () => {
  return (
    <a href="https://wa.me/447849432449" className="whatsapp-float" target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp">
      <i className="fab fa-whatsapp"></i>
    </a>
  );
};

export default WhatsAppButton;
